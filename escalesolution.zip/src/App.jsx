import React from 'react';
import Front from './components/front';
import './app.css';

function App() {
  return (
    <div className="App">
        <Front />
    </div>
  );
}

export default App;