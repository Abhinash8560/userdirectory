
import React from 'react'
import './front.css';
import Users from "../page/Users"

const Front = () => {
  return(
    <Users/>
  )
}


  
 
export default Front;